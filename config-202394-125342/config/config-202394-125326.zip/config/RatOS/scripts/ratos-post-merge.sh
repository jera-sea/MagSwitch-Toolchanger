#!/bin/bash

sudo /home/pi/printer_data/config/RatOS/scripts/ratos-update.sh
