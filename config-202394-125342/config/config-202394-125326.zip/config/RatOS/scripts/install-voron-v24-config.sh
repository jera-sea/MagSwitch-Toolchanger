#!/bin/bash

tail -n +2 /home/pi/printer_data/config/RatOS/templates/voron-v24-printer.template.cfg > /home/pi/printer_data/config/printer.cfg
