#!/bin/bash

sudo /home/pi/printer_data/config/RatOS/scripts/klipper-mcu-update.sh
